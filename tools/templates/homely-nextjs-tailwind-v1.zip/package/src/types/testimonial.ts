export type Testimonial = {
    review: string
    name: string
    position: string
    image: string
}