export type FeaturedProperty = {
    scr: string
    alt: string
}